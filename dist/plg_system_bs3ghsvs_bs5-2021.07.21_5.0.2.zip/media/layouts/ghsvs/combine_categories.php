<?php
/**
2015-01-10 GHSVS
für about-africa
 */

defined('JPATH_BASE') or die;
//combinedCatsGhsvs
?>
<dd class="category-name"><?php echo $displayData['item']->combinedCatsGhsvs;?></dd>